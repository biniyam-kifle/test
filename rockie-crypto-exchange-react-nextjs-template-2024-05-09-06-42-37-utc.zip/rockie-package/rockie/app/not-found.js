
export default function NotFound() {
    return (
        <>
            Error 404
        </>
    )
}
